//
//  DetalleClaseViewController.swift
//  Ufit
//
//  Created by ALEJANDRO on 24/05/17.
//  Copyright © 2017 AHA Universo. All rights reserved.
//

import UIKit

class DetallePerfilViewController: UIViewController {
    
    var tituloTxt = ""
    
    // MI PERFIL VARS
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationController?.navigationBar.setBackgroundImage(UIImage(), for: .default)
        self.navigationController?.navigationBar.shadowImage = UIImage()
        self.navigationController?.navigationBar.isTranslucent = true
        self.navigationController?.view.backgroundColor = .clear
        
        self.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
    }
    
    override func viewDidAppear(_ animated: Bool) {
        self.title = self.tituloTxt
        
        let defaults = UserDefaults.standard
        let dtema = defaults.object(forKey: "tema") as? String!
        print(dtema!)
    }
    
    
    // MARK: - MI PERFIL
    
    @IBAction func aplicarTemaVerde(_ sender: Any) {
        let defaults = UserDefaults.standard
        defaults.set("verde", forKey: "tema")
        defaults.synchronize()
    }

    @IBAction func aplicarTemaAzul(_ sender: Any) {
        let defaults = UserDefaults.standard
        defaults.set("azul", forKey: "tema")
        defaults.synchronize()
    }
    
    @IBAction func aplicarTemaNegro(_ sender: Any) {
        let defaults = UserDefaults.standard
        defaults.set("negro", forKey: "tema")
        defaults.synchronize()
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

     
    
}
